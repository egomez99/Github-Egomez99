// This is a test harness for your module
// You should do something interesting in this harness 
// to test out the module and to provide instructions 
// to users on how to use it by example.


// open a single window
var win = Ti.UI.createWindow({
	backgroundColor:'white'
});
var label = Ti.UI.createLabel();
win.add(label);
win.open();

// TODO: write your module tests here
var array = require('org.appcelerator.array');
Ti.API.info("module is => " + array);

label.text = array.example();

Ti.API.info("module exampleProp is => " + array.exampleProp);
array.exampleProp = "This is a test value";

if (Ti.Platform.name == "android") {
	var proxy = array.createExample({
		message: "Creating an example Proxy",
		backgroundColor: "red",
		width: 100,
		height: 100,
		top: 100,
		left: 150
	});

	proxy.printMessage("Hello world!");
	proxy.message = "Hi world!.  It's me again.";
	proxy.printMessage("Hello world!");
	win.add(proxy);
}

Ti.API.info( "array.encrypt( ['d', 'e', 'm', 'o'] ): " );
Ti.API.info ( array.encrypt( ['d', 'e', 'm', 'o'] ));
    
var myArray = new Array();
    myArray[0] = 'd';
    myArray[1] = 'e';
    myArray[2] = 'm';
    myArray[3] = 'o';
    
Ti.API.info ( "array.encrypt( myArray ): ");
Ti.API.info ( array.encrypt( myArray ));

Ti.API.info("array.encrypt( new Array('d', 'e', 'm', 'o') )");
Ti.API.info ( array.encrypt( new Array('d', 'e', 'm', 'o') ) );

Ti.API.info("Number Array [1,2,3]: ");
Ti.API.info( array.encrypt([1,2,3]) );

Ti.API.info("Letters Array ['a', 'b', 'c']: ");
Ti.API.info( array.encrypt(['a', 'b', 'c']) );




