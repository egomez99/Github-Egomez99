function Controller() {
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    arguments[0] ? arguments[0]["__parentSymbol"] : null;
    arguments[0] ? arguments[0]["$model"] : null;
    var $ = this;
    var exports = {};
    $.__views.image = Ti.UI.createWindow({
        exitOnClose: "false",
        modal: "true",
        id: "image",
        backgroundColor: "#ffffff",
        navBarHidden: "true",
        fullscreen: "true"
    });
    $.__views.image && $.addTopLevelView($.__views.image);
    $.__views.imageview = Ti.UI.createImageView({
        backgroundColor: "white",
        width: Ti.Platform.displayCaps.platformWidth,
        height: Ti.Platform.displayCaps.platformHeight,
        id: "imageview",
        image: "",
        enableZoomControls: "true"
    });
    $.__views.image.add($.__views.imageview);
    exports.destroy = function() {};
    _.extend($, $.__views);
    var arg1 = arguments[0] || {};
    var data = [];
    data = arg1;
    $.imageview.setImage(data.image);
    alert(" data.image: " + data.image);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;