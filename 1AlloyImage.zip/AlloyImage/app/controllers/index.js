function doClick(e) {

	var animage = '/animage.jpg';
	//var image = Alloy.createController('image', {image: data.full_photo}).getView();
	var image = Alloy.createController('image', {
		image : animage
	}).getView();
	image.open();
	image.animate({
		opacity : 1.0,
		duration : 250
	});
}

$.index.open(); 