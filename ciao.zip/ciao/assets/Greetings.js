/**
 *  Example component interface Greetings.js
 */
function Greetings() {}
 
Greetings.prototype.getGreeting = function() {};
Greetings.prototype.getAppName = function() {};
 
Greetings.createPrototype = function() {
    return new Greetings();
}
 
 
exports.createPrototype = Greetings.createPrototype;