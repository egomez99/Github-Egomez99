/**
 *  Example native extension interface implementation for ciao_iphone.js
 */
var CiaoModule = require('com.mfoundry.mb.ciao/Ciao');
// CHANGE: Greetings needs to be required here so it can be used
var GreetingsInterface = require('com.mfoundry.mb.ciao/Greetings');
 
var NATIVE_EXTENSION_APP_NAME = "Ciao! Native Extension";
 
function Ciao(configuration) {
    this.configuration = configuration;
}
 
Ciao.prototype = GreetingsInterface.createPrototype();
 
Ciao.prototype.getGreeting = function() {
    
    return CiaoModule.helloFromItaly();
}
 
Ciao.prototype.getAppName = function() {
    return NATIVE_EXTENSION_APP_NAME;
}
 
// CHANGE: Create and export a new instance of Ciao
module.exports = new Ciao();