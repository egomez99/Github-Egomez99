function Controller() {
    function doClick() {
        var animage = "/animage.jpg";
        var image = Alloy.createController("image", {
            image: animage
        }).getView();
        image.open();
        image.animate({
            opacity: 1,
            duration: 250
        });
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    arguments[0] ? arguments[0]["__parentSymbol"] : null;
    arguments[0] ? arguments[0]["$model"] : null;
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.index = Ti.UI.createWindow({
        backgroundColor: "white",
        id: "index",
        exitOnClose: "false",
        navBarHidden: "true",
        fullscreen: "true"
    });
    $.__views.index && $.addTopLevelView($.__views.index);
    $.__views.label = Ti.UI.createLabel({
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        color: "#000",
        text: "Click me to open an Image",
        id: "label"
    });
    $.__views.index.add($.__views.label);
    doClick ? $.__views.label.addEventListener("click", doClick) : __defers["$.__views.label!click!doClick"] = true;
    $.__views.activityIndicator = Ti.UI.createView({
        backgroundImage: "/animage.jpg",
        width: "34dp",
        height: "34dp",
        bottom: "40dp",
        id: "activityIndicator"
    });
    $.__views.index.add($.__views.activityIndicator);
    $.__views.scroll = Ti.UI.createScrollView({
        layout: "vertical",
        top: "27dp",
        height: Ti.Platform.displayCaps.platformHeight,
        width: Ti.Platform.displayCaps.platformWidth,
        opacity: 0,
        id: "scroll"
    });
    $.__views.index.add($.__views.scroll);
    exports.destroy = function() {};
    _.extend($, $.__views);
    $.index.open();
    var animation = require("alloy/animation");
    var t = Ti.UI.create2DMatrix();
    var a = Titanium.UI.createAnimation();
    t = t.rotate(-360);
    a.transform = t;
    a.repeat = 3;
    a.duration = 1e3;
    var animationHandler = function() {
        Ti.API.info(" :: animationHandler :: ");
        a.removeEventListener("complete", animationHandler);
        $.index.remove($.activityIndicator);
        animation.fadeIn($.scroll, 500, function() {});
    };
    a.addEventListener("complete", animationHandler);
    $.activityIndicator.animate(a);
    Ti.API.info(" :: activityIndicator.animate :: ");
    __defers["$.__views.label!click!doClick"] && $.__views.label.addEventListener("click", doClick);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;