function doClick(e) {

	var animage = '/animage.jpg';
	//var image = Alloy.createController('image', {image: data.full_photo}).getView();
	var image = Alloy.createController('image', {
		image : animage
	}).getView();
	image.open();
	image.animate({
		opacity : 1.0,
		duration : 250
	});
}

$.index.open(); 

var animation = require('alloy/animation');

// Spin the image
var t = Ti.UI.create2DMatrix();
var a = Titanium.UI.createAnimation();
t = t.rotate(-360);
a.transform = t;
a.repeat = 3;
a.duration = 1000;


var content;

var animationHandler = function() {
	Ti.API.info(' :: animationHandler :: ');
  a.removeEventListener('complete',animationHandler);
  $.index.remove($.activityIndicator);
  animation.fadeIn($.scroll, 500, function(e){});
};
a.addEventListener('complete',animationHandler);
$.activityIndicator.animate(a);
Ti.API.info(' :: activityIndicator.animate :: ');