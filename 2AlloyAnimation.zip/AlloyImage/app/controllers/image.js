var arg1 = arguments[0] || {};
var data = [];  
data = arg1;

$.imageview.setImage(data.image);
Ti.API.info(' data.image: '+ data.image);

//Alloy.Globals.apm.leaveBreadcrumb("{event:'Image URL Set', status: 'Crash'}");

//Alloy.Globals.Tracker.trackScreen("View Image");